﻿namespace programmeertool_amanuel
{
    partial class frmWhileofforlus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWhileofforlus));
            this.btnGeefadvies = new System.Windows.Forms.Button();
            this.lbxResult = new System.Windows.Forms.ListBox();
            this.lblKeuzefor = new System.Windows.Forms.Label();
            this.rbdFor = new System.Windows.Forms.RadioButton();
            this.rdbWhile = new System.Windows.Forms.RadioButton();
            this.lblBeginwaarde = new System.Windows.Forms.Label();
            this.lblGeefbeginwaarde = new System.Windows.Forms.Label();
            this.txtGeefbw = new System.Windows.Forms.TextBox();
            this.lblEindewaard = new System.Windows.Forms.Label();
            this.lblgroterdan = new System.Windows.Forms.Label();
            this.lblKleiner = new System.Windows.Forms.Label();
            this.txtGeefwaarde = new System.Windows.Forms.TextBox();
            this.lblGeefEW = new System.Windows.Forms.Label();
            this.rdbGroter = new System.Windows.Forms.RadioButton();
            this.rdbKleiner = new System.Windows.Forms.RadioButton();
            this.lblStapgrotte = new System.Windows.Forms.Label();
            this.lblRekenkundige = new System.Windows.Forms.Label();
            this.rdbPlus = new System.Windows.Forms.RadioButton();
            this.rdbMin = new System.Windows.Forms.RadioButton();
            this.lblGeefeindewaarde = new System.Windows.Forms.Label();
            this.txtEindwaarde2 = new System.Windows.Forms.TextBox();
            this.grpEeen = new System.Windows.Forms.GroupBox();
            this.grpTwee = new System.Windows.Forms.GroupBox();
            this.chkIs = new System.Windows.Forms.CheckBox();
            this.lblGelijkaan = new System.Windows.Forms.Label();
            this.grpDrie = new System.Windows.Forms.GroupBox();
            this.grpVier = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblProgrammeertool = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grpEeen.SuspendLayout();
            this.grpTwee.SuspendLayout();
            this.grpDrie.SuspendLayout();
            this.grpVier.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGeefadvies
            // 
            this.btnGeefadvies.Location = new System.Drawing.Point(505, 634);
            this.btnGeefadvies.Name = "btnGeefadvies";
            this.btnGeefadvies.Size = new System.Drawing.Size(286, 37);
            this.btnGeefadvies.TabIndex = 0;
            this.btnGeefadvies.Text = "Geef advies";
            this.btnGeefadvies.UseVisualStyleBackColor = true;
            this.btnGeefadvies.Click += new System.EventHandler(this.btnGeefadvies_Click);
            // 
            // lbxResult
            // 
            this.lbxResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxResult.FormattingEnabled = true;
            this.lbxResult.ItemHeight = 25;
            this.lbxResult.Location = new System.Drawing.Point(333, 130);
            this.lbxResult.Name = "lbxResult";
            this.lbxResult.Size = new System.Drawing.Size(613, 479);
            this.lbxResult.TabIndex = 1;
            // 
            // lblKeuzefor
            // 
            this.lblKeuzefor.AutoSize = true;
            this.lblKeuzefor.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKeuzefor.Location = new System.Drawing.Point(5, 22);
            this.lblKeuzefor.Name = "lblKeuzefor";
            this.lblKeuzefor.Size = new System.Drawing.Size(214, 22);
            this.lblKeuzefor.TabIndex = 2;
            this.lblKeuzefor.Text = " 1. Keuze for of While lus ";
            // 
            // rbdFor
            // 
            this.rbdFor.AutoSize = true;
            this.rbdFor.Location = new System.Drawing.Point(51, 58);
            this.rbdFor.Name = "rbdFor";
            this.rbdFor.Size = new System.Drawing.Size(53, 24);
            this.rbdFor.TabIndex = 3;
            this.rbdFor.TabStop = true;
            this.rbdFor.Text = "for";
            this.rbdFor.UseVisualStyleBackColor = true;
            // 
            // rdbWhile
            // 
            this.rdbWhile.AutoSize = true;
            this.rdbWhile.Location = new System.Drawing.Point(142, 58);
            this.rdbWhile.Name = "rdbWhile";
            this.rdbWhile.Size = new System.Drawing.Size(73, 24);
            this.rdbWhile.TabIndex = 4;
            this.rdbWhile.TabStop = true;
            this.rdbWhile.Text = "While";
            this.rdbWhile.UseVisualStyleBackColor = true;
            // 
            // lblBeginwaarde
            // 
            this.lblBeginwaarde.AutoSize = true;
            this.lblBeginwaarde.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBeginwaarde.Location = new System.Drawing.Point(8, 22);
            this.lblBeginwaarde.Name = "lblBeginwaarde";
            this.lblBeginwaarde.Size = new System.Drawing.Size(213, 22);
            this.lblBeginwaarde.TabIndex = 5;
            this.lblBeginwaarde.Text = " 2. BeginWaarde bepalen";
            // 
            // lblGeefbeginwaarde
            // 
            this.lblGeefbeginwaarde.AutoSize = true;
            this.lblGeefbeginwaarde.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblGeefbeginwaarde.Location = new System.Drawing.Point(37, 100);
            this.lblGeefbeginwaarde.Name = "lblGeefbeginwaarde";
            this.lblGeefbeginwaarde.Size = new System.Drawing.Size(144, 20);
            this.lblGeefbeginwaarde.TabIndex = 9;
            this.lblGeefbeginwaarde.Text = "Geef beginwaarde";
            // 
            // txtGeefbw
            // 
            this.txtGeefbw.Location = new System.Drawing.Point(187, 94);
            this.txtGeefbw.Name = "txtGeefbw";
            this.txtGeefbw.Size = new System.Drawing.Size(62, 26);
            this.txtGeefbw.TabIndex = 10;
            // 
            // lblEindewaard
            // 
            this.lblEindewaard.AutoSize = true;
            this.lblEindewaard.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEindewaard.Location = new System.Drawing.Point(8, 22);
            this.lblEindewaard.Name = "lblEindewaard";
            this.lblEindewaard.Size = new System.Drawing.Size(184, 20);
            this.lblEindewaard.TabIndex = 11;
            this.lblEindewaard.Text = " 3. Eindewaarde bepalen";
            // 
            // lblgroterdan
            // 
            this.lblgroterdan.AutoSize = true;
            this.lblgroterdan.Location = new System.Drawing.Point(37, 69);
            this.lblgroterdan.Name = "lblgroterdan";
            this.lblgroterdan.Size = new System.Drawing.Size(86, 20);
            this.lblgroterdan.TabIndex = 12;
            this.lblgroterdan.Text = "Groter dan";
            // 
            // lblKleiner
            // 
            this.lblKleiner.AutoSize = true;
            this.lblKleiner.Location = new System.Drawing.Point(37, 110);
            this.lblKleiner.Name = "lblKleiner";
            this.lblKleiner.Size = new System.Drawing.Size(92, 20);
            this.lblKleiner.TabIndex = 13;
            this.lblKleiner.Text = "Kleiner  dan";
            // 
            // txtGeefwaarde
            // 
            this.txtGeefwaarde.Location = new System.Drawing.Point(180, 150);
            this.txtGeefwaarde.Name = "txtGeefwaarde";
            this.txtGeefwaarde.Size = new System.Drawing.Size(62, 26);
            this.txtGeefwaarde.TabIndex = 15;
            // 
            // lblGeefEW
            // 
            this.lblGeefEW.AutoSize = true;
            this.lblGeefEW.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblGeefEW.Location = new System.Drawing.Point(37, 156);
            this.lblGeefEW.Name = "lblGeefEW";
            this.lblGeefEW.Size = new System.Drawing.Size(144, 20);
            this.lblGeefEW.TabIndex = 14;
            this.lblGeefEW.Text = "Geef eindewaarde";
            // 
            // rdbGroter
            // 
            this.rdbGroter.AutoSize = true;
            this.rdbGroter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbGroter.Location = new System.Drawing.Point(142, 67);
            this.rdbGroter.Name = "rdbGroter";
            this.rdbGroter.Size = new System.Drawing.Size(49, 29);
            this.rdbGroter.TabIndex = 16;
            this.rdbGroter.TabStop = true;
            this.rdbGroter.Text = ">";
            this.rdbGroter.UseVisualStyleBackColor = true;
            // 
            // rdbKleiner
            // 
            this.rdbKleiner.AutoSize = true;
            this.rdbKleiner.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbKleiner.Location = new System.Drawing.Point(142, 106);
            this.rdbKleiner.Name = "rdbKleiner";
            this.rdbKleiner.Size = new System.Drawing.Size(49, 29);
            this.rdbKleiner.TabIndex = 17;
            this.rdbKleiner.TabStop = true;
            this.rdbKleiner.Text = "<";
            this.rdbKleiner.UseVisualStyleBackColor = true;
            // 
            // lblStapgrotte
            // 
            this.lblStapgrotte.AutoSize = true;
            this.lblStapgrotte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStapgrotte.Location = new System.Drawing.Point(8, 32);
            this.lblStapgrotte.Name = "lblStapgrotte";
            this.lblStapgrotte.Size = new System.Drawing.Size(176, 20);
            this.lblStapgrotte.TabIndex = 18;
            this.lblStapgrotte.Text = " 4. Stapgrootte bepalen";
            // 
            // lblRekenkundige
            // 
            this.lblRekenkundige.AutoSize = true;
            this.lblRekenkundige.Location = new System.Drawing.Point(37, 84);
            this.lblRekenkundige.Name = "lblRekenkundige";
            this.lblRekenkundige.Size = new System.Drawing.Size(105, 20);
            this.lblRekenkundige.TabIndex = 19;
            this.lblRekenkundige.Text = "rekenkundige";
            // 
            // rdbPlus
            // 
            this.rdbPlus.AutoSize = true;
            this.rdbPlus.Location = new System.Drawing.Point(156, 82);
            this.rdbPlus.Name = "rdbPlus";
            this.rdbPlus.Size = new System.Drawing.Size(43, 24);
            this.rdbPlus.TabIndex = 20;
            this.rdbPlus.TabStop = true;
            this.rdbPlus.Text = "+";
            this.rdbPlus.UseVisualStyleBackColor = true;
            // 
            // rdbMin
            // 
            this.rdbMin.AutoSize = true;
            this.rdbMin.Location = new System.Drawing.Point(219, 82);
            this.rdbMin.Name = "rdbMin";
            this.rdbMin.Size = new System.Drawing.Size(39, 24);
            this.rdbMin.TabIndex = 21;
            this.rdbMin.TabStop = true;
            this.rdbMin.Text = "-";
            this.rdbMin.UseVisualStyleBackColor = true;
            // 
            // lblGeefeindewaarde
            // 
            this.lblGeefeindewaarde.AutoSize = true;
            this.lblGeefeindewaarde.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblGeefeindewaarde.Location = new System.Drawing.Point(37, 135);
            this.lblGeefeindewaarde.Name = "lblGeefeindewaarde";
            this.lblGeefeindewaarde.Size = new System.Drawing.Size(144, 20);
            this.lblGeefeindewaarde.TabIndex = 22;
            this.lblGeefeindewaarde.Text = "Geef eindewaarde";
            // 
            // txtEindwaarde2
            // 
            this.txtEindwaarde2.Location = new System.Drawing.Point(180, 129);
            this.txtEindwaarde2.Name = "txtEindwaarde2";
            this.txtEindwaarde2.Size = new System.Drawing.Size(62, 26);
            this.txtEindwaarde2.TabIndex = 23;
            // 
            // grpEeen
            // 
            this.grpEeen.Controls.Add(this.lblKeuzefor);
            this.grpEeen.Controls.Add(this.rbdFor);
            this.grpEeen.Controls.Add(this.rdbWhile);
            this.grpEeen.Location = new System.Drawing.Point(12, 12);
            this.grpEeen.Name = "grpEeen";
            this.grpEeen.Size = new System.Drawing.Size(286, 101);
            this.grpEeen.TabIndex = 25;
            this.grpEeen.TabStop = false;
            this.grpEeen.Text = "stap 1";
            // 
            // grpTwee
            // 
            this.grpTwee.Controls.Add(this.chkIs);
            this.grpTwee.Controls.Add(this.lblGelijkaan);
            this.grpTwee.Controls.Add(this.lblBeginwaarde);
            this.grpTwee.Controls.Add(this.lblGeefbeginwaarde);
            this.grpTwee.Controls.Add(this.txtGeefbw);
            this.grpTwee.Location = new System.Drawing.Point(12, 119);
            this.grpTwee.Name = "grpTwee";
            this.grpTwee.Size = new System.Drawing.Size(286, 146);
            this.grpTwee.TabIndex = 26;
            this.grpTwee.TabStop = false;
            this.grpTwee.Text = "stap 2";
            // 
            // chkIs
            // 
            this.chkIs.AutoSize = true;
            this.chkIs.Location = new System.Drawing.Point(156, 62);
            this.chkIs.Name = "chkIs";
            this.chkIs.Size = new System.Drawing.Size(44, 24);
            this.chkIs.TabIndex = 19;
            this.chkIs.Text = "=";
            this.chkIs.UseVisualStyleBackColor = true;
            // 
            // lblGelijkaan
            // 
            this.lblGelijkaan.AutoSize = true;
            this.lblGelijkaan.Location = new System.Drawing.Point(37, 66);
            this.lblGelijkaan.Name = "lblGelijkaan";
            this.lblGelijkaan.Size = new System.Drawing.Size(88, 20);
            this.lblGelijkaan.TabIndex = 11;
            this.lblGelijkaan.Text = "Gelijke aan";
            // 
            // grpDrie
            // 
            this.grpDrie.Controls.Add(this.lblEindewaard);
            this.grpDrie.Controls.Add(this.lblgroterdan);
            this.grpDrie.Controls.Add(this.lblKleiner);
            this.grpDrie.Controls.Add(this.lblGeefEW);
            this.grpDrie.Controls.Add(this.txtGeefwaarde);
            this.grpDrie.Controls.Add(this.rdbGroter);
            this.grpDrie.Controls.Add(this.rdbKleiner);
            this.grpDrie.Location = new System.Drawing.Point(12, 271);
            this.grpDrie.Name = "grpDrie";
            this.grpDrie.Size = new System.Drawing.Size(286, 184);
            this.grpDrie.TabIndex = 27;
            this.grpDrie.TabStop = false;
            this.grpDrie.Text = "stap 3";
            // 
            // grpVier
            // 
            this.grpVier.Controls.Add(this.lblStapgrotte);
            this.grpVier.Controls.Add(this.lblRekenkundige);
            this.grpVier.Controls.Add(this.rdbPlus);
            this.grpVier.Controls.Add(this.rdbMin);
            this.grpVier.Controls.Add(this.txtEindwaarde2);
            this.grpVier.Controls.Add(this.lblGeefeindewaarde);
            this.grpVier.Location = new System.Drawing.Point(12, 461);
            this.grpVier.Name = "grpVier";
            this.grpVier.Size = new System.Drawing.Size(286, 168);
            this.grpVier.TabIndex = 28;
            this.grpVier.TabStop = false;
            this.grpVier.Text = "stap 4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(911, 610);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 17);
            this.label1.TabIndex = 29;
            this.label1.Text = "V.02";
            // 
            // btnReset
            // 
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReset.Location = new System.Drawing.Point(809, 91);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(137, 33);
            this.btnReset.TabIndex = 30;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblProgrammeertool
            // 
            this.lblProgrammeertool.AutoSize = true;
            this.lblProgrammeertool.Font = new System.Drawing.Font("Mongolian Baiti", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgrammeertool.Location = new System.Drawing.Point(409, 10);
            this.lblProgrammeertool.Name = "lblProgrammeertool";
            this.lblProgrammeertool.Size = new System.Drawing.Size(425, 59);
            this.lblProgrammeertool.TabIndex = 31;
            this.lblProgrammeertool.Text = "Programmeertool";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(401, 663);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "© Amanuel";
            // 
            // frmWhileofforlus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 692);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblProgrammeertool);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.grpVier);
            this.Controls.Add(this.grpDrie);
            this.Controls.Add(this.grpTwee);
            this.Controls.Add(this.grpEeen);
            this.Controls.Add(this.lbxResult);
            this.Controls.Add(this.btnGeefadvies);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmWhileofforlus";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "While en for lus tool";
            this.grpEeen.ResumeLayout(false);
            this.grpEeen.PerformLayout();
            this.grpTwee.ResumeLayout(false);
            this.grpTwee.PerformLayout();
            this.grpDrie.ResumeLayout(false);
            this.grpDrie.PerformLayout();
            this.grpVier.ResumeLayout(false);
            this.grpVier.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGeefadvies;
        private System.Windows.Forms.ListBox lbxResult;
        private System.Windows.Forms.Label lblKeuzefor;
        private System.Windows.Forms.RadioButton rbdFor;
        private System.Windows.Forms.RadioButton rdbWhile;
        private System.Windows.Forms.Label lblBeginwaarde;
        private System.Windows.Forms.Label lblGeefbeginwaarde;
        private System.Windows.Forms.TextBox txtGeefbw;
        private System.Windows.Forms.Label lblEindewaard;
        private System.Windows.Forms.Label lblgroterdan;
        private System.Windows.Forms.Label lblKleiner;
        private System.Windows.Forms.TextBox txtGeefwaarde;
        private System.Windows.Forms.Label lblGeefEW;
        private System.Windows.Forms.RadioButton rdbGroter;
        private System.Windows.Forms.RadioButton rdbKleiner;
        private System.Windows.Forms.Label lblStapgrotte;
        private System.Windows.Forms.Label lblRekenkundige;
        private System.Windows.Forms.RadioButton rdbPlus;
        private System.Windows.Forms.RadioButton rdbMin;
        private System.Windows.Forms.Label lblGeefeindewaarde;
        private System.Windows.Forms.TextBox txtEindwaarde2;
        private System.Windows.Forms.GroupBox grpEeen;
        private System.Windows.Forms.GroupBox grpTwee;
        private System.Windows.Forms.GroupBox grpDrie;
        private System.Windows.Forms.GroupBox grpVier;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblProgrammeertool;
        private System.Windows.Forms.Label lblGelijkaan;
        private System.Windows.Forms.CheckBox chkIs;
        private System.Windows.Forms.Label label2;
    }
}

