﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programmeertool_amanuel
{
    public partial class frmWhileofforlus : Form
    {
        public frmWhileofforlus()
        {
            InitializeComponent();
        }

        private void btnGeefadvies_Click(object sender, EventArgs e)
        {
            try
            {

                // decarelen 
                int beginwaarde = int.Parse(txtGeefbw.Text); // zorgt ervoor dat je cijfer in kan vullen 
                int eindwaarde = int.Parse(txtGeefwaarde.Text); // zorgt ervoor dat je cijfer in kan vullen 
                int eindewaade2 = int.Parse(txtEindwaarde2.Text); // zorgt ervoor dat je cijfer in kan vullen 
                string IS = "="; // geeft Is de waarde van =
                string plus = "null"; // geeft Is de waarde van null
                string min = "null"; // geeft Is de waarde van null
                string kliener = "<";// geeft Is de waarde van <

                // stap grote code hier onder plus

                if (eindewaade2 == 1) // als de waarde van eindewaarde 1 is dan wordt de waarde van puls i++ 
                {
                    plus = "i++";
                }
                else // anders wordt de waarde van pluss i+ (eindewaarde)
                {
                    plus = $"i+={eindewaade2}";
                }

                // stap grote code hier onder min
                
                if (eindewaade2 == 1) // als de waarde van eindewaarde 1 is dan wordt de waarde van min i-- 
                {
                    min = "i--";
                }
                else // als de waarde van eindewaarde 1 is dan wordt de waarde van puls i- (eindewaard)
                {
                    min = $"i-={eindewaade2}";
                    //  eindewaade2.ToString($"i+={eindewaade2}");
                }
                // kliener of groter codes
                if (rdbKleiner.Checked) // als de de knop rdbKleiner wordt ingekilt dan wordt de waarde van Kleiner <
                {
                    kliener = "<";

                }
                else if (rdbGroter.Checked)  // als de de knop rbdGroter wordt ingekilt dan wordt de waarde van Kleiner<
                {
                    kliener = ">";
                }


                // als de ingevoerde getal bij beginwaarde  meer is dan einde waarde dan krijgt de gebruiker foutmelding
                if (beginwaarde >= eindwaarde) // als de waarde van beginwaarde meer is dan de eindewaarde dan verschijnt  er tekst met   Erorr 101! Er dient een foutmelding te komen op het scherm.

                {
                    lbxResult.Items.Clear();
                    MessageBox.Show(" Erorr 101! Er dient een foutmelding te komen op het scherm.");
                    //lbxResult.Items.Add("Error 404! Er dient een foutmelding te komen op het scherm.");
                }
             
                // als de ingevoerde getal  0 of  minder   dan krijgt de gebruiker foutmelding

             /*   if (eindewaade2 <= 0 || beginwaarde <= 0 || eindwaarde <= 0)
                {

                    lbxResult.Items.Clear();
                   MessageBox.Show(" Error 404! Er dient een foutmelding te komen op het scherm.");
                   // lbxResult.Items.Add("Error 404! Er dient een foutmelding te komen op het scherm.");
                }*/

                // for radiobutton code 
                // als de gebruiker de for radiobutton kiest
                if (chkIs.Checked)  // als de de knop chkIs wordt ingekilt dan wordt de waarde van is =
                {
                    IS = "=";
                }
                else //  // anders wordt de waarde van pluss is niks
                {
                    IS = "";
                }
                if (rbdFor.Checked) // als de de knop rdbfor wordt ingekilt dan verschijnt
                /*    for (int i = 0; i < length; i++)
                    {

                    }*/ // (voorbeeld)
                {
                    lbxResult.Items.Clear(); // de code verdewijdert de inhoud van lbxresult
                    string forlus = "null"; // de code geeft de forlus waard van null

                    if (rdbPlus.Checked) // // als de de knop rdbPlus wordt ingekilt dan wordt de waarde van forlus $"for int i = {beginwaarde};  {IS}{kliener}{eindwaarde};  {plus})"
                    {
                        forlus = $"for (int i = {beginwaarde};  {IS}{kliener}{eindwaarde};  {plus})";
                        lbxResult.Items.Add(forlus);

                    }

                    else if (rdbMin.Checked) // als de de knop rdbPlus wordt ingekilt dan wordt de waarde van forlus  $"for (int i = {beginwaarde};  {IS}{kliener}{eindwaarde};  {min})"
                    {
                        forlus = $"for (int i = {beginwaarde};  {IS}{kliener}{eindwaarde};  {min})";
                        lbxResult.Items.Add(forlus);
                    }
                    lbxResult.Items.Add(" {"); // de waarde {
                    lbxResult.Items.Add(""); // de waarde ""
                    lbxResult.Items.Add(""); // de waarde ""
                    lbxResult.Items.Add(" }"); // // de waarde }
                }

                // while codes
                // als de gebruiker de while radiobutton kiest
                if (rdbWhile.Checked)  // als de de knop rdbfor wordt ingekilt dan verschijnt
                  /*  int i = 0;
                while (i > =10)
                {

                }*/ //(voorbeeld)

                {
                    lbxResult.Items.Clear();// de code verdewijdert de inhoud van lbxresult

                    lbxResult.Items.Add($"int i = {beginwaarde};"); // de code print int i = {beginwaard}
                    // if (rdbGroter.Checked
                    if (rdbGroter.Checked) // als de de knop rdbgroter wordt ingekilt dan wordt er "while (i >{IS}{eindwaarde}  geprint
                    {
                        lbxResult.Items.Add($"while (i >{IS}{eindwaarde}) ");
                    }
                    else if (rdbKleiner.Checked)  // als de de knop rdbkleiner wordt ingekilt dan wordt er "while (i <{IS}{eindwaarde}  geprint
                    {
                        lbxResult.Items.Add($"while (i <{IS}{eindwaarde}); ");
                    }
                    lbxResult.Items.Add("{"); // de code print {
                    // 

                    // stapgrote while code
                    if (rdbPlus.Checked) // als de de knop rbdPlus wordt ingekilt dan wordt er de waarde van plus geprint
                    {
                        lbxResult.Items.Add(    $"{plus};");
                    }
                    else if (rdbMin.Checked) // als de de knop rbdMin wordt ingekilt dan wordt er de waarde van plus geprint
                    {
                        lbxResult.Items.Add(     $"{min};");
                    }
                    lbxResult.Items.Add("}"); // de code print {
                }
            }
            // als de gebruiker iets fouts invoerd dan komt er tekst ER IS EEN FOUT OPGETREDEN!! op de listbox
            catch
            {

                lbxResult.Items.Clear(); // de code verdewijdert de inhoud van lbxresult
                lbxResult.Items.Add("ER IS EEN FOUT OPGETREDEN!!"); // als er iets fouts gaat dan wordt er ER IS EEN FOUT OPGETREDEN!! geprint 

            }


            // twee

        }
        // Als je op de knop reset klikt dan word alles van listbox verdwijdert 
        private void btnReset_Click(object sender, EventArgs e)
        {
            lbxResult.Items.Clear(); // de code verdewijdert de inhoud van lbxresult

        }


    }
}

